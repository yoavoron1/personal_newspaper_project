"""FastAPI endpoints עבור יצירת עיתון אישי."""

# Load .env BEFORE models are imported so DATABASE_URL is visible to models.py
from dotenv import load_dotenv
load_dotenv()

import json
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import quote


import uvicorn
from fastapi import FastAPI, Form, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from werkzeug.security import generate_password_hash

from models import Article, SessionLocal, User, create_tables

BASE_DIR = Path(__file__).resolve().parent
CACHE_FILE = BASE_DIR / "newspaper_cache.json"


# ── Lifespan ──────────────────────────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: connect to PostgreSQL and create tables. Raises on failure."""
    db_url = os.getenv("DATABASE_URL", "")
    masked = db_url[:25] + "…" if len(db_url) > 25 else db_url
    print(f"[startup] Connecting to database: {masked}")
    try:
        create_tables()
        print("[startup] PostgreSQL tables ready ✓")
    except Exception as exc:
        print(f"\n[FATAL] Cannot connect to PostgreSQL:\n  {exc}\n")
        print("  ↳ Check that DATABASE_URL in .env points to the Railway PUBLIC proxy URL,")
        print("    not the internal postgres.railway.internal address.\n")
        raise  # re-raise so uvicorn exits with a non-zero code
    yield


app = FastAPI(lifespan=lifespan)
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def load_cached_newspaper() -> Optional[Tuple[Dict, List[Dict]]]:
    """Read newspaper_cache.json (kept for /update-news write-back compatibility)."""
    if not CACHE_FILE.exists():
        return None
    try:
        data = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        return data["newspaper_data"], data["selected_articles"]
    except Exception:
        return None


def load_articles_from_db() -> Optional[Tuple[str, List[Dict]]]:
    """Fetch the latest user and their articles from PostgreSQL.

    Returns (user_full_name, enriched_articles) or None if nothing found.
    """
    db = SessionLocal()
    try:
        user = db.query(User).order_by(User.created_at.desc()).first()
        if not user:
            return None

        db_arts = (
            db.query(Article)
            .filter(Article.user_id == user.id)
            .order_by(Article.timestamp.desc())
            .limit(8)
            .all()
        )
        if not db_arts:
            return None

        articles: List[Dict] = []
        for idx, art in enumerate(db_arts):
            content = art.content or ""
            # First paragraph → card preview text
            first_para = content.split("\n\n")[0].strip()
            articles.append({
                "id":             idx,
                "title":          art.title or "",
                "short_summary":  first_para[:500],
                "long_summary":   content,
                "image":          art.image_url or "",
                "image_keywords": "",
                "source_name":    art.source or "",
                "source":         art.source or "",
                "topic":          "",
                "why_it_matters": "",
                "personal_impact":"",
                "url":            "",
                "country_origin": "",
                "bullets":        [],
                "commentary":     "",
            })

        return user.full_name, articles

    except Exception as exc:
        print(f"[DB] Error loading articles: {exc}")
        return None
    finally:
        db.close()


# ── Routes ────────────────────────────────────────────────────────────────────

@app.post("/update-news")
async def update_news(request: Request, api_key: str = Query(None)):
    expected = os.getenv("API_KEY", "")
    print(f"[update-news] received={api_key[:3] if api_key else 'NONE'} expected={expected[:3] if expected else 'NONE'}")
    if expected and api_key != expected:
        raise HTTPException(status_code=401, detail="Unauthorized")
    body = await request.json()
    CACHE_FILE.write_text(json.dumps(body, ensure_ascii=False, indent=2), encoding="utf-8")
    print("[update-news] Cache updated successfully.")
    return JSONResponse({"status": "ok"})


@app.get("/article/{article_id}", response_class=HTMLResponse)
def article_page(request: Request, article_id: int):
    result = load_articles_from_db()
    if not result:
        raise HTTPException(status_code=404, detail="No newspaper data available")
    user_name, articles = result
    if article_id < 0 or article_id >= len(articles):
        raise HTTPException(status_code=404, detail="Article not found")
    return templates.TemplateResponse(
        request=request,
        name="article.html",
        context={
            "article":          articles[article_id],
            "newspaper_title":  "העיתון האישי",
            "article_id":       article_id,
            "total_articles":   len(articles),
        },
    )


@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    result = load_articles_from_db()
    if not result:
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={
                "title":       "העיתון האישי שלך",
                "intro":       "",
                "articles":    [],
                "coming_soon": True,
            },
        )
    user_name, articles = result
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "title":       "העיתון האישי",
            "intro":       f"שלום {user_name} — הנה הגיליון האישי שלך",
            "articles":    articles,
            "coming_soon": False,
        },
    )


# ── Registration ──────────────────────────────────────────────────────────────

@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request, success: str = ""):
    return templates.TemplateResponse(
        request=request,
        name="register.html",
        context={"error": "", "success": success},
    )


@app.post("/register", response_class=HTMLResponse)
async def register_submit(
    request: Request,
    full_name:      str           = Form(...),
    email:          str           = Form(...),
    password:       str           = Form(...),
    occupation:     Optional[str] = Form(None),
    interests_text: Optional[str] = Form(None),
    bio:            Optional[str] = Form(None),
):
    # Normalise optional fields — None or whitespace-only → empty string
    occupation     = (occupation     or "").strip()
    interests_text = (interests_text or "").strip()
    bio            = (bio            or "").strip()

    if not full_name.strip() or not email.strip() or not password.strip():
        return templates.TemplateResponse(
            request=request, name="register.html",
            context={"error": "נא למלא את כל השדות החובה.", "success": ""}, status_code=400,
        )
    if len(password) < 8:
        return templates.TemplateResponse(
            request=request, name="register.html",
            context={"error": "הסיסמה חייבת להכיל לפחות 8 תווים.", "success": ""}, status_code=400,
        )

    db = SessionLocal()
    try:
        if db.query(User).filter(User.email == email.strip().lower()).first():
            return templates.TemplateResponse(
                request=request, name="register.html",
                context={"error": "כתובת האימייל כבר רשומה במערכת.", "success": ""}, status_code=409,
            )
        db.add(User(
            email=email.strip().lower(),
            password_hash=generate_password_hash(password),
            full_name=full_name.strip(),
            occupation=occupation,
            interests_text=interests_text,
            bio=bio,
        ))
        db.commit()
        print(f"[register] New user registered: {email.strip().lower()}")
    except Exception as exc:
        db.rollback()
        print(f"[register] DB error: {exc}")
        return templates.TemplateResponse(
            request=request, name="register.html",
            context={"error": "אירעה שגיאה בשמירת הנתונים. נסה שנית.", "success": ""}, status_code=500,
        )
    finally:
        db.close()

    return RedirectResponse(url="/register?success=1", status_code=303)


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)
